// ScriptPad — Configuration
const CONFIG = {
  SUPABASE_URL: 'https://okwbfzzbysfkpiuobjkx.supabase.co',
  SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9rd2JmenpieXNma3BpdW9iamt4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODEwMzUyNTQsImV4cCI6MjA5NjYxMTI1NH0.VY6w2ul8SCcTYfTeq07y_yXiw5lEkKITZykY_wo1oYk',
  // Lemon Squeezy checkout URLs (will be filled in once products are created)
  LEMONSQUEEZY_MONTHLY_URL: '',
  LEMONSQUEEZY_ANNUAL_URL: ''
};
